public class proc_params
{
    public long rob_size;
    public long iq_size;
    public long width;
}
